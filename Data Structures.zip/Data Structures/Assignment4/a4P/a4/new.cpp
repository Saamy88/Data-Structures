/*#include<iostream>
#include"sequence.h"


using namespace std;
using namespace cs3358Fall2012Assign04;



int main()
{

	sequence<double> s1;

	s1.add(2);


    cout << s1.current();









	return 0;
}

*/
